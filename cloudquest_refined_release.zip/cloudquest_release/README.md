# CloudQuest Linux Workshop

CloudQuest is a small, self-contained browser learning project for people beginning Linux and cloud fundamentals. It is intentionally a workshop rather than a glossy dashboard: read a task, try a command, inspect the result, and explain what you learned.

## Start here

1. Download and extract the ZIP, or open `index.html` directly.
2. Choose a lab and read its goal before using the hint.
3. Type commands into the terminal. The shortcut buttons and command history are there to make mobile use easier.
4. Check the mission goal after doing the work.
5. Write a short reflection and use **Export progress** to keep a portable backup.

To publish it, upload `index.html` and the `tests/` folder to a GitHub repository and enable GitHub Pages for the appropriate branch/folder.

## What it is—and isn't

This is a JavaScript command simulator with a virtual filesystem. It does **not** execute a real Bash shell or commands on your device, and it does not connect to a cloud account. System/network output is illustrative. Progress and reflections are stored in the current browser on the current device; they do not automatically sync across devices. Export progress before clearing browser data or switching devices.

The supported subset includes basic navigation, listing, file creation/reading/copy/move/removal, simple permission changes, identity inspection, `grep`, `wc`, `sort`, `head`, selected illustrative system/network commands, basic pipes, redirection, and `;` command chaining. Use `help` inside the terminal for the in-app list.

## Tests

With Node.js installed, run:

```sh
node tests/terminal-engine.test.cjs
```

This exercises the actual command-engine functions extracted from `index.html`. The browser integration harness is `tests/browser-smoke.html`; serve this directory over HTTP and open that page in a browser to test the UI/command path. Engine tests are not a substitute for manual iOS Safari, desktop, keyboard-accessibility, contrast, and real-device checks.
