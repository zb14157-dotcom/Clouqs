const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/i)?.[1];
if (!script) throw new Error('Application script not found');
new vm.Script(script, { filename: 'cloudquest-inline.js' });

// Run the real command engine without the browser UI wiring so tests are deterministic.
const engineEnd = script.indexOf('let historyIndex=0;');
assert.notEqual(engineEnd, -1, 'UI wiring boundary found');
const sandbox = { console, Date, Math, JSON };
vm.createContext(sandbox);
vm.runInContext(script.slice(0, engineEnd) + `\nglobalThis.api={labs,initFs,normalize,parent,base,getNode,fsExists,readFile,writeFile,tokenize,executeSimple,runPipeline,runLine,getState:()=>({fs,cwd,xp,completed,current,cmdHistory,commandResults}),setCwd:v=>cwd=v,setHistory:v=>cmdHistory=v,setResults:v=>commandResults=v};`, sandbox);
const api = sandbox.api;
const tests = [];
function test(name, fn) { try { reset(); fn(); tests.push({ name, ok: true }); } catch (error) { tests.push({ name, ok: false, detail: error.message }); } }
function reset() { api.initFs(); api.setHistory([]); api.setResults([]); }
function run(command) { return api.runLine(command); }

reset();
test('six guided labs are present', () => assert.equal(api.labs.length, 6));
test('home path and default workspace exist', () => { assert.equal(api.getState().cwd, '/home/student'); assert.equal(api.fsExists('~/cloudquest-lab'), true); });
test('pwd reports current directory', () => assert.equal(run('pwd'), '/home/student'));
test('mkdir -p creates nested directories', () => { run('mkdir -p projects/logs'); assert.equal(api.getNode('projects/logs').type, 'dir'); });
test('mkdir -p is idempotent', () => { run('mkdir -p projects/logs'); assert.equal(run('mkdir -p projects/logs'), ''); });
test('quoted echo and overwrite redirection preserve spaces', () => { run("echo 'ERROR disk full' > app.log"); assert.equal(api.readFile('app.log'), 'ERROR disk full\n'); });
test('append redirection appends a second line', () => { run("echo 'ERROR disk full' > app.log"); run("echo 'INFO healthy' >> app.log"); assert.equal(api.readFile('app.log'), 'ERROR disk full\nINFO healthy\n'); });
test('wc -l counts newline-terminated file lines', () => { run("echo 'one' > list.txt"); run("echo 'two' >> list.txt"); assert.equal(run('wc -l list.txt'), '2'); });
test('grep output pipes to wc -l', () => { run("echo 'ERROR one' > app.log"); run("echo 'INFO fine' >> app.log"); run("echo 'ERROR two' >> app.log"); assert.equal(run('grep ERROR app.log | wc -l'), '2'); });
test('chmod u+x updates owner execute bit', () => { run('touch deploy.sh'); run('chmod u+x deploy.sh'); assert.match(run('ls -l deploy.sh'), /^-rw[x-]r--r--/); assert.equal(api.getNode('deploy.sh').mode[2], 'x'); });
test('copy into an existing directory uses the source filename', () => { run('touch deploy.sh'); run('mkdir archive'); run('cp deploy.sh archive'); assert.equal(api.fsExists('archive/deploy.sh'), true); });
test('mv removes original file and preserves content', () => { run("echo 'backup' > a.txt"); run('mv a.txt b.txt'); assert.equal(api.fsExists('a.txt'), false); assert.equal(api.readFile('b.txt'), 'backup\n'); });
test('rm removes files and updates parent directory', () => { run('touch discard.txt'); run('rm discard.txt'); assert.equal(api.fsExists('discard.txt'), false); assert.equal(run('ls'), 'cloudquest-lab/'); });
test('rm refuses to delete directories', () => { assert.match(run('rm cloudquest-lab'), /refusing to remove directories/); });
test('unmatched quotes are rejected', () => assert.match(run("echo 'broken"), /unmatched quote/));
test('unknown and privileged commands fail closed', () => { assert.match(run('sudo id'), /command not found/); assert.match(run('curl example.com'), /command not found/); });
test('cat reads piped input when no filename is given', () => { assert.equal(run("echo 'hello world' | cat"), 'hello world'); });
test('sort reads piped input', () => { assert.equal(run("echo 'z\na' | sort"), 'a\nz'); });
test('home shorthand and parent traversal normalize safely', () => { assert.equal(api.normalize('~/cloudquest-lab/../cloudquest-lab'), '/home/student/cloudquest-lab'); assert.equal(api.normalize('/../../tmp'), '/tmp'); });
test('missing file errors are explicit', () => assert.match(run('cat absent.txt'), /No such file or directory/));
test('directory file writes are refused', () => assert.match(run('echo hello > cloudquest-lab'), /Is a directory/));

const failed = tests.filter(t => !t.ok);
for (const t of tests) console.log(`${t.ok ? 'PASS' : 'FAIL'} — ${t.name}${t.detail ? ` (${t.detail})` : ''}`);
console.log(`\n${tests.length - failed.length}/${tests.length} engine tests passed`);
if (failed.length) process.exitCode = 1;
