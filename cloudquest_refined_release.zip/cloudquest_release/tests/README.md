# CloudQuest tests

- `terminal-engine.test.cjs` runs deterministic regression tests against the actual command engine embedded in `../index.html`. Run with `node tests/terminal-engine.test.cjs` from this directory's parent. The suite currently covers 21 cases.
- `browser-smoke.html` is an integration harness for a real browser. Serve the project over HTTP (for example, `python3 -m http.server 8000`) and open `http://localhost:8000/tests/browser-smoke.html`.

Passing engine tests does not prove iOS Safari compatibility or full browser accessibility. The app should not be called production-ready until those checks have been performed.
